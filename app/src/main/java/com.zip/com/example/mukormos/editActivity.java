package com.example.mukormos;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

public class editActivity extends AppCompatActivity {

    private FirebaseUser firebaseUser;
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firebaseFirestore;
    private CollectionReference myTimes;
    EditText edittimeEDT;
    Button edittimeButton;
    String documentid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        setContentView(R.layout.activity_edit);
        FirebaseApp.initializeApp(this);
        edittimeButton = findViewById(R.id.edittimeButton);
        edittimeEDT = findViewById(R.id.edittimeEDT);

        firebaseFirestore = FirebaseFirestore.getInstance();
        myTimes = firebaseFirestore.collection("Times");

        querytime();
        edittimeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myTimes.document(documentid).update("idopont",edittimeEDT.getText().toString());
                Intent intent = new Intent(editActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private void querytime() {
        myTimes.whereEqualTo("id", getIntent().getStringExtra("id"))
                .limit(1)
                .get()
                .addOnSuccessListener((queryDocumentSnapshots -> {
                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        myTime time = document.toObject(myTime.class);
                        edittimeEDT.setText(time.getIdopont());
                        documentid = document.getId();
                    }
                }));

    }

}