package com.example.mukormos;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.core.Query;

import org.w3c.dom.Comment;

import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private FirebaseUser firebaseUser;
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firebaseFirestore;
    private CollectionReference myTimes;

    EditText ujidopontEDT;
    Button ujidopontButton;
    String idopont;
    Date jelenido = new Date();
    RecyclerView recyclerView;
    ArrayList<myTime> myTimeList;
    timeitemAdapter timeAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        FirebaseApp.initializeApp(this);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        ujidopontEDT = findViewById(R.id.idopontEDT);
        ujidopontButton = findViewById(R.id.idopontletrehozButton);

        firebaseFirestore = FirebaseFirestore.getInstance();
        myTimes = firebaseFirestore.collection("Times");

        ujidopontButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!ujidopontEDT.getText().toString().isEmpty()){
                    idopont = ujidopontEDT.getText().toString();
                }else{
                    ujidopontEDT.setError("Kérlek adj meg egy időpontot!");
                    return;
                }

                myTimes.add(new myTime(idopont, firebaseUser.getEmail(), jelenido)).addOnSuccessListener(documentReference -> {
                    String generatedId = documentReference.getId();
                    documentReference.update("id", documentReference.getId());
                });
                initData();
            }
        });

        recyclerView = findViewById(R.id.idopontlistaRVV);
        recyclerView.setLayoutManager(new GridLayoutManager(this,1));
        myTimeList = new ArrayList<>();
        timeAdapter = new timeitemAdapter(this,myTimeList,this::initData);
        recyclerView.setAdapter(timeAdapter);

        initData();

    }
    private void initData(){
        myTimeList.clear();
        queryTimes();
    }
    private void queryTimes() {
        myTimes.orderBy("ido")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        myTime myComment = document.toObject(myTime.class);
                        myTimeList.add(myComment);
                        Log.d("Firestore", myComment.toString());
                    }
                    timeAdapter.notifyDataSetChanged();
                })
                .addOnFailureListener(e -> Log.e("Firestore", "Error loading comments", e));
    }

}